export {default as BarController} from './controller.bar';
export {default as BubbleController} from './controller.bubble';
export {default as DoughnutController} from './controller.doughnut';
export {default as LineController} from './controller.line';
export {default as PolarAreaController} from './controller.polarArea';
export {default as PieController} from './controller.pie';
export {default as RadarController} from './controller.radar';
export {default as ScatterController} from './controller.scatter';
